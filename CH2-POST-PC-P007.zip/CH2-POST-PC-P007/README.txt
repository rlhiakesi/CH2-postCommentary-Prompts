SBL 1.0 resolved page rendering package
Render target: CH2-POST-PC-P007
Entry file: CH2-POST-PC-P007.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Randy Hyde Workstation.png
  Assets/CH2_Commentary_Production_Sheet.docx
  Assets/Manga Me Character Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
